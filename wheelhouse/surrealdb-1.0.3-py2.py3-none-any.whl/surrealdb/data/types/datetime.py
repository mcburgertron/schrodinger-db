class IsoDateTimeWrapper:

    def __init__(self, dt: str):
        self.dt = dt
